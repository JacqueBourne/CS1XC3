/**
 * @file student.h
 * @author fuj43
 * @brief Defined a Student type including first_name, last_name, id, grades, num_grades as constructers.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */


typedef struct _student 
{ 
  char first_name[50];//array contain char
  char last_name[50];//array contain char
  char id[11];//array contain char
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
//add_grade, average, print_student, and generate_random_student function declarations. 
